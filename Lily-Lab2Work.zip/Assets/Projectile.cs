using System.Runtime.InteropServices;
using UnityEngine;

public class Projectile : MonoBehaviour
{

    [SerializeField] GameObject targetPrefab;
    [SerializeField] private float explosionForce = 10f;
    [SerializeField] private float explosionRadius = 5f;
    private bool isGrenade = false;

    void OnCollisionEnter()
    {
        if (isGrenade)
        {
            Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
            foreach (Collider hit in colliders)
            {
                Rigidbody rb = hit.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
                }
            }
        }
        Destroy(gameObject);
    }

    public void SetIsGrenade(bool value)
    {
        isGrenade = value;
    }
}
