using UnityEngine;

public class WeaponBlock : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("collided");
        if (collision.gameObject.name == "HandgunSphere")
        {
            Debug.Log("Collided with HandgunSphere");
        }
    }
}
