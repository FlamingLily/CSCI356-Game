using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    [Header("Settings")]
    [SerializeField] private float moveSpeed = 20f;
    [SerializeField] private float mouseSensitivity = 0.1f;
    [SerializeField] private float maxVertRange = 80f;
    [SerializeField] private float throwMod = 1f;
    [SerializeField] private string currentWeapon;

    [Header("References")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private CharacterController characterController;
    [SerializeField] private PlayerControls inputHandler;
    [SerializeField] private Rigidbody projectilePrefab;

    private Vector3 currentMove;
    private float currentVertRotation;
    private float lastProjFire = 0;
    private float lastJump = 0;
    private bool hasDoubleJumped = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        if (currentWeapon == null || currentWeapon == "")
        {
            currentWeapon = "None";
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            return;
        }

        if (Input.GetMouseButtonDown(0) && Cursor.lockState == CursorLockMode.None)
        {
            Cursor.lockState = CursorLockMode.Locked;
        }

        HandleMove();
        HandleLook();
        FireProjectile();
    }

    private Vector3 GetWorldDir()
    {
        Vector3 inputDir = new Vector3(inputHandler.MoveInput.x, 0, inputHandler.MoveInput.y);
        Vector3 worldDir = transform.TransformDirection(inputDir);
        return worldDir.normalized;
    }

    public void SetCurrentWeapon(string weapon)
    {
        currentWeapon = weapon;
    }

    private void FireProjectile()
    {

        switch (currentWeapon)
        {
            case "Handgun":
                if (inputHandler.JustFired)
                {
                    Vector3 spawnPos = playerCamera.transform.position;
                    spawnPos += playerCamera.transform.forward * 2.5f; // don't collide with player and immediately despawn

                    Rigidbody firedProjectile = Instantiate(projectilePrefab, spawnPos, playerCamera.transform.rotation);
                    firedProjectile.linearVelocity = playerCamera.transform.forward * 40; // Set the speed of the projectile
                }
                break;
            case "SubmachineGun":
                if (inputHandler.IsFiring && Time.time > lastProjFire + 0.2f)
                {
                    lastProjFire = Time.time;

                    Vector3 spawnPos = playerCamera.transform.position;
                    spawnPos += playerCamera.transform.forward * 2.5f; // don't collide with player and immediately despawn
                    Vector3 randomSway = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f));
                    spawnPos += randomSway;

                    Rigidbody firedProjectile = Instantiate(projectilePrefab, spawnPos, playerCamera.transform.rotation);
                    firedProjectile.linearVelocity = playerCamera.transform.forward * 40; // Set the speed of the projectile
                }
                break;
            case "Grenade":
                if (inputHandler.JustFired)
                {
                    lastProjFire = Time.time;
                }
                if (inputHandler.FireReleased)
                {
                    float throwForce = (Time.time - lastProjFire) * throwMod; // more force from hold length
                    Vector3 spawnPos = playerCamera.transform.position;
                    spawnPos += playerCamera.transform.forward * 2.5f; // don't collide with player and immediately despawn

                    Rigidbody firedProjectile = Instantiate(projectilePrefab, spawnPos, playerCamera.transform.rotation);
                    firedProjectile.GetComponent<Projectile>().SetIsGrenade(true);
                    firedProjectile.linearVelocity = playerCamera.transform.forward * throwForce; // Set the speed of the projectile
                }
                break;
            default:
                return;
        }
    }

    private void HandleMove()
    {
        currentMove.x = GetWorldDir().x * moveSpeed;
        currentMove.z = GetWorldDir().z * moveSpeed;
        HandleJump();
        characterController.Move(currentMove * Time.deltaTime);
    }

    private void HandleLook()
    {
        float mouseX = inputHandler.LookInput.x * mouseSensitivity;
        float mouseY = inputHandler.LookInput.y * mouseSensitivity;

        transform.Rotate(0, mouseX, 0);

        currentVertRotation = Mathf.Clamp(currentVertRotation - mouseY, -maxVertRange, maxVertRange);
        playerCamera.transform.localRotation = Quaternion.Euler(currentVertRotation, 0, 0);
    }

    private void HandleJump()
    {

        bool safeToJump = Time.time > lastJump + 0.2f; // so not to instantly eat the double jump on the first press
        if (characterController.isGrounded && safeToJump)
        {
            currentMove.y = -0.5f;
            hasDoubleJumped = false;


            if (inputHandler.IsJumping)
            {
                currentMove.y = 5f;
                lastJump = Time.time;
            }
        }
        else if (inputHandler.IsJumping && !hasDoubleJumped && safeToJump)
        {
            currentMove.y = 5f;
            hasDoubleJumped = true;
            lastJump = Time.time;
        }
        else
        {
            currentMove.y += Physics.gravity.y * Time.deltaTime;
        }
    }
}
