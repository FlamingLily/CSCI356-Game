using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerControls : MonoBehaviour
{
    [Header("Input Action Asset")]
    [SerializeField] private InputActionAsset inputActions;

    private InputAction moveAction;
    private InputAction lookAction;
    private InputAction fireAction;
    private InputAction jumpAction;

    public Vector2 MoveInput { get; private set; }
    public Vector2 LookInput { get; private set; }
    public bool IsFiring { get; private set; }
    public bool JustFired { get; private set; } // for handgun - only true if fired this frame
    public bool FireReleased { get; private set; } // for grenade - true on frame lmb is released
    public bool IsJumping { get; private set; }


    private void Awake()
    {
        InputActionMap actionMap = inputActions.FindActionMap("Player");
        moveAction = actionMap.FindAction("Movement");
        lookAction = actionMap.FindAction("Camera");
        fireAction = actionMap.FindAction("Fire");
        jumpAction = actionMap.FindAction("Jump");

        GetValuesFromInput();
    }

    private void Update()
    {
        if (fireAction.WasPressedThisFrame())
        {
            JustFired = true;
        }
        else
        {
            JustFired = false;
        }
        if (fireAction.WasReleasedThisFrame())
        {
            FireReleased = true;
        }
        else
        {
            FireReleased = false;
        }
    }

    private void GetValuesFromInput()
    {
        moveAction.performed += inputInfo => MoveInput = inputInfo.ReadValue<Vector2>();
        moveAction.canceled += inputInfo => MoveInput = Vector2.zero;

        lookAction.performed += inputInfo => LookInput = inputInfo.ReadValue<Vector2>();
        lookAction.canceled += inputInfo => LookInput = Vector2.zero;

        fireAction.performed += inputInfo => IsFiring = true;
        fireAction.canceled += inputInfo => IsFiring = false;

        jumpAction.performed += inputInfo => IsJumping = true;
        jumpAction.canceled += inputInfo => IsJumping = false;
    }

    private void OnEnable()
    {
        moveAction.Enable();
        lookAction.Enable();
        fireAction.Enable();
        jumpAction.Enable();
    }

    private void OnDisable()
    {
        moveAction.Disable();
        lookAction.Disable();
        fireAction.Disable();
        jumpAction.Disable();
    }
}
