using UnityEngine;

public class WeaponSphere : MonoBehaviour
{
    [SerializeField] private string weaponType;

    private Renderer rdr;
    private float respawnTime;
    private bool active = true;

    void Start()
    {   
        if (string.IsNullOrEmpty(weaponType))
        {
            weaponType = "Handgun";
        }

        rdr = GetComponent<Renderer>();

        switch (weaponType)
        {
            case "Handgun":
                rdr.material.color = Color.red;
                break;
            case "SubmachineGun":
                rdr.material.color = Color.blue;
                break;
            case "Grenade":
                rdr.material.color = Color.green;
                break;
            default:
                Debug.LogWarning("Unknown weapon type: " + weaponType);
                break;
        }
    }

    void Update()
    {
        if (Time.time > respawnTime)
        {
            gameObject.transform.localScale = Vector3.one;
            active = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player" && active)
        {
            gameObject.transform.localScale = Vector3.zero; // cheap way to hide the sphere
            respawnTime = Time.time + 5f;
            active = false;

            other.GetComponent<PlayerMovement>().SetCurrentWeapon(weaponType);
        }
    }
}
