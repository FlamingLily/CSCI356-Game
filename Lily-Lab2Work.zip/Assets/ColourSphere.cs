using System.Collections;
using UnityEngine;

public class ColourSphere : MonoBehaviour
{

    Renderer rdr;
    float nextFire = 0f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rdr = GetComponent<Renderer>();
        // pick a colour to start
        Color randomColour = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
        rdr.material.color = randomColour;

        nextFire = Time.time + Random.Range(0f, 1f); // first fire after random time - makes each orb change independently
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > nextFire)
        {
            Color randomColour = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
            rdr.material.color = randomColour;

            // update timer
            nextFire = Time.time + 1f;
        }
    }
}
