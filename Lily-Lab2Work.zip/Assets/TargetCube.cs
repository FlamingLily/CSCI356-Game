using UnityEngine;

public class TargetCube : MonoBehaviour
{

    [SerializeField] private GameObject myScaler;
    [SerializeField] private float scaleFactor = 0.1f; 
    private int hits = 0;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Projectile"))
        {
            hits++;
            myScaler.transform.localScale -= new Vector3(scaleFactor, scaleFactor, scaleFactor);
            if (hits >= 10)
            {
                Destroy(gameObject);
                Destroy(myScaler);
            }
        }
    }
}
