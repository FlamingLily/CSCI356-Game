Weapons:
Red - Handgun
Blue - SMG
Green - Grenade, Available on the roof of the building.

WASD and mouse to move, click to fire. Hold down LMB to charge grenade throw.